package read.origindata;

import java.util.Arrays;

public class OriginDataVo {

	private int len=0;
	private int[] ml;     
	private int[] xy;
	private int[] PI;   
	private int[] status;
	private double [] RR;     
	private int[] head1;
	private int[] head2;
	private int[] battery;
	private int[] index;
	private long[] numTime;
	private int[] checkSum;
	private int[] ir1;         //PPG
	private int[] ir2;

	public OriginDataVo(int len) {
		super();
		this.len = len;
	}
	public int getLen() {
		return len;
	}
	public void setLen(int len) {
		this.len = len;
	}
	public int[] getMl() {
		return ml;
	}
	public void setMl(int[] ml) {
		this.ml = ml;
	}
	public int[] getXy() {
		return xy;
	}
	public void setXy(int[] xy) {
		this.xy = xy;
	}
	public int[] getPI() {
		return PI;
	}
	public void setPI(int[] pI) {
		PI = pI;
	}
	public int[] getStatus() {
		return status;
	}
	public void setStatus(int[] status) {
		this.status = status;
	}
	public double[] getRR() {
		return RR;
	}
	public void setRR(double[] rR) {
		RR = rR;
	}
	public int[] getHead1() {
		return head1;
	}
	public void setHead1(int[] head1) {
		this.head1 = head1;
	}
	public int[] getHead2() {
		return head2;
	}
	public void setHead2(int[] head2) {
		this.head2 = head2;
	}
	public int[] getBattery() {
		return battery;
	}
	public void setBattery(int[] battery) {
		this.battery = battery;
	}
	public int[] getIndex() {
		return index;
	}
	public void setIndex(int[] index) {
		this.index = index;
	}
	public long[] getNumTime() {
		return numTime;
	}
	public void setNumTime(long[] numTime) {
		this.numTime = numTime;
	}
	public int[] getCheckSum() {
		return checkSum;
	}
	public void setCheckSum(int[] checkSum) {
		this.checkSum = checkSum;
	}
	public int[] getIr1() {
		return ir1;
	}
	public void setIr1(int[] ir1) {
		this.ir1 = ir1;
	}
	public int[] getIr2() {
		return ir2;
	}
	public void setIr2(int[] ir2) {
		this.ir2 = ir2;
	}
	@Override
	public String toString() {
		return "OriginDataVo [len=" + len 
				+ ",\r\n ml=" + Arrays.toString(ml) 
				+ ",\r\n xy=" + Arrays.toString(xy) 
				+ ",\r\n PI="+ Arrays.toString(PI) 
				+ ",\r\n status=" + Arrays.toString(status) 
				+ ",\r\n RR=" + Arrays.toString(RR)
				+ ",\r\n head1=" + Arrays.toString(head1) 
				+ ",\r\n head2=" + Arrays.toString(head2) 
				+ ",\r\n battery="+ Arrays.toString(battery) 
				+ ",\r\n index=" + Arrays.toString(index) 
				+ ",\r\n numTime="+ Arrays.toString(numTime) 
				+ ",\r\n checkSum=" + Arrays.toString(checkSum) 
				+ ",\r\n ir1=" + Arrays.toString(ir1)
				+ ",\r\n ir2=" + Arrays.toString(ir2) + "]";
	}
	
}
