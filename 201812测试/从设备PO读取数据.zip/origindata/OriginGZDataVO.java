package read.origindata;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.io.Writer;
import java.util.zip.GZIPInputStream;

/**
 * 读取web后台数据的类
 * 
 * @author hd
 *
 */
public class OriginGZDataVO {
	private String filepath;
	private boolean flag_five = false;
	private int len;
	private final int data_length = 30;
	private RandomAccessFile raf;
	private OriginDataVo origindata;
	private String TAG = "ReadGZData";

	private int[] ml;
	private int[] xy;
	private int[] PI;
	private int[] status;
	private double[] RR;
	private int[] head1;
	private int[] head2;
	private int[] battery;
	private int[] index;
	private long[] numTime;
	private int[] checkSum;

	private final int dataPackageLength = 21; // 1+1+1+1+4+1+1+1+1+8+1 = 21
	private final double samplingFrequency = 100d;

	public OriginGZDataVO(String filePath) throws IOException {
		super();
		this.filepath = filePath;
		this.flag_five = false;
		readFile(filePath);
	}

	public OriginGZDataVO(File file) throws IOException {
		super();
		readFile(file);
	}

	public OriginGZDataVO(InputStream mInputStream) throws IOException {
		super();
		readData(mInputStream);
	}

	/**
	 * Read data from a file with the specified file path.
	 * 
	 * @param filePath
	 * @throws IOException
	 */
	private void readFile(String filePath) throws IOException {
		readFile(new File(filePath));
	}

	/**
	 * Read data from a file.
	 * 
	 * @param file
	 * @throws IOException
	 */

	private void readFile(File file) throws IOException {
		readData(new GZIPInputStream(new FileInputStream(file)));
	}

	/**
	 * Split data from a inputStream which contains all data of a file.
	 * 
	 * @param mInputStream
	 */
	private void readData(InputStream mInputStream) {
		try {
			BufferedInputStream bufferedInputStream = new BufferedInputStream(mInputStream);
			int length = 0;
			bufferedInputStream.mark(Integer.MAX_VALUE);
			while (bufferedInputStream.read() != -1) {
				length++;
			}
			len = length / dataPackageLength;
			origindata = new OriginDataVo(len);
			bufferedInputStream.reset();
			ml = new int[length];
			xy = new int[length];
			PI = new int[length];
			status = new int[length];
			RR = new double[length];
			head1 = new int[length];
			head2 = new int[length];
			battery = new int[length];
			index = new int[length];
			numTime = new long[length];
			checkSum = new int[length];
			byte[] data = new byte[dataPackageLength];
			for (int i = 0; i < len; i++) {
				bufferedInputStream.read(data);
				ml[i] = 0xff & data[0];
				xy[i] = 0xff & data[1];
				PI[i] = 0xff & data[2];
				status[i] = 0xff & data[3];
				RR[i] = (float) ((((int) (0xFF & data[4]) << 24) + ((int) (0xFF & data[5]) << 16)
						+ ((int) (0xFF & data[6]) << 8) + (0xFF & data[7])) / samplingFrequency);
				head1[i] = 0xff & data[8];
				head2[i] = 0xff & data[9];
				battery[i] = 0xff & data[10];
				index[i] = 0xff & data[11];
				numTime[i] = ((long) (0xFF & data[12]) << 56) + ((long) (0xFF & data[13]) << 48)
						+ ((long) (0xFF & data[14]) << 40) + ((long) (0xFF & data[15]) << 32)
						+ ((long) (0xFF & data[16]) << 24) + ((long) (0xFF & data[17]) << 16)
						+ ((long) (0xFF & data[18]) << 8) + (long) (0xFF & data[19]);
				checkSum[i] = 0xff & data[20];
			}
			origindata.setLen(len);
			origindata.setMl(ml);
			origindata.setXy(xy);
			origindata.setPI(PI);
			origindata.setStatus(status);
			origindata.setRR(RR);
			origindata.setHead1(head1);
			origindata.setHead2(head2);
			origindata.setBattery(battery);
			origindata.setIndex(index);
			origindata.setNumTime(numTime);
			origindata.setCheckSum(checkSum);

			bufferedInputStream.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * 另存一份TXT文件
	 * 
	 * @param filepath
	 */
	public void saveASTxT() {
		String recordpath = filepath.replace(".gz", "_RR.txt");
		File file = new File(recordpath);
		try {
			Writer out = new FileWriter(file);
			
			out.write("Time(long)" + "  " + "ml" + "  " + "xy" + "  " + "RR" + "  " + "PI\r\n");
			out.flush();
			for (int i = 0; i < origindata.getLen(); i++) {
				out.write("\r\n" + origindata.getNumTime()[i] + "  " + origindata.getMl()[i] + "  "
						+ origindata.getXy()[i] + "  " + origindata.getRR()[i] + "  " + origindata.getPI()[i]);
				out.flush();
			}
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * 将RR间期数据另存一份TXT文件
	 * 
	 * @param filepath
	 */
	public void saveRRASTxT() {
		String recordpath = filepath.replace(".gz", "_RR.txt");
		File file = new File(recordpath);
		try {
			Writer out = new FileWriter(file);
			for (int i = 0; i < origindata.getLen(); i++) {
				//
				out.write(origindata.getRR()[i] + "\r\n");
				out.flush();
			}
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String getFilepath() {
		return filepath;
	}

	public boolean isFlag_five() {
		return flag_five;
	}

	public int getLen() {
		return len;
	}

	public int getData_length() {
		return data_length;
	}

	public RandomAccessFile getRaf() {
		return raf;
	}

	public OriginDataVo getOrigindata() {
		return origindata;
	}

	public String getTAG() {
		return TAG;
	}

	public int[] getMl() {
		return ml;
	}

	public int[] getXy() {
		return xy;
	}

	public int[] getPI() {
		return PI;
	}

	public int[] getStatus() {
		return status;
	}

	public double[] getRR() {
		return RR;
	}

	public int[] getHead1() {
		return head1;
	}

	public int[] getHead2() {
		return head2;
	}

	public int[] getBattery() {
		return battery;
	}

	public int[] getIndex() {
		return index;
	}

	public long[] getNumTime() {
		return numTime;
	}

	public int[] getCheckSum() {
		return checkSum;
	}

	public int getDataPackageLength() {
		return dataPackageLength;
	}

	public double getSamplingFrequency() {
		return samplingFrequency;
	}

}
