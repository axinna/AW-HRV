package read.origindata;

import java.io.File;

import org.junit.Test;

/**
 * 读取原始数据(本地的)
 * 
 * Taiir体检宝存的本地数据文件在：CheckUp文件夹下
 * 睡眠管家和睡眠管家呼吸版的本地数据文件在：SleepCare文件夹下
 * 
 * 
 * @author hd
 *
 */
public class TestDemo1 {
	/**
	 * 呼吸版数据读取
	 * 
	 * 读取手机SleepCare/data文件夹下的呼吸版数据
	 */
	@Test
	public void run1() {
		// 第一步：指定文件的存储路径
		/*String filepath = "C:" + File.separator + "Users" + File.separator + "PC" + File.separator + "Desktop"
				+ File.separator + "breath" + File.separator + "data" + File.separator + "lyd1.gz";*/
		String filepath = "C:" + File.separator + "Users" + File.separator + "PC" + File.separator + "Desktop"
				+ File.separator +"ga_2018-12-17_19-14-58_SleepData_status.dat";
		// 第二步：实例化ReadBinary_1类，需要指定文件的存储路径filepath
		ReadBinary_1 in = new ReadBinary_1(filepath);
		// 第三步：得到OriginDataVo1，通过此类可以得到数据文件中的数据
		OriginDataVo1 data = in.readBinary();
		// 得到数据ml
		int[] ml = data.getMl();
		// 得到数据xy
		int[] xy = data.getXy();
		// 得到ir
		int[] ir = data.getIr1();
		// 得到数据P
		int[] p = data.getPress();
		// 得到数据axis_x
		short[] axis_x = data.getAxis_x();
		// 输出数据到工作台上
		for (int i = 0; i < ml.length; i++) {
			System.out.println(ir[i] + "    " + axis_x[i] + "    " + p[i]);
		}
		// 另外：如果需要改变文件存储路径以及文件中的数据种类可以修改ReadBinary_1类的saveASTxT方法
		// 原文件名
		System.out.println(filepath);
		//另存一份txt文件，文件名为：原文件名+.txt
		in.saveASTxT();
	}

	/**
	 * 非呼吸版数据读取
	 * 
	 * 读取手机CheckUp下的.dat数据文件
	 */
	@Test
	public void run2() {
		// 第一步：指定文件的存储路径
		String filepath = "C:" + File.separator + "Users" + File.separator + "PC" + File.separator + "Desktop"
				+File.separator+ "贺东_2018-06-28_16-20-54_SleepData_status.dat";
		// 第二步：实例化ReadBinary_1类，需要指定文件的存储路径filepath
		ReadBinary in=new ReadBinary(filepath);
		OriginDataVo originDataVo = in.readBinary();
		System.out.println(filepath);
		//另存一份txt文件
		in.saveASTxT();
	}
	
	
}
