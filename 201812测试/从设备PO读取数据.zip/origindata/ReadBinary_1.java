package read.origindata;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.io.Writer;
import java.util.zip.GZIPInputStream;

public class ReadBinary_1 {
	private String filepath;
	private boolean flag_five;
	private float packagelength = 100; // 设备发送的数据包的长度
	private int len;
	private int packageRate=100;
	
	private final int data_length = 35;
	private RandomAccessFile raf;
	private OriginDataVo1 origindata;
	private String TAG="ReadBinary";
	
	private int[] ml;
	private int[] xy;
	private int[] PI;
	private int[] status;
	private double[] RR;
	private int[] head1;
	private int[] head2;
	private int[] battery;
	private int[] index;
	private long[] numTime;
	private int[] checkSum;
	private int[] ir1;
	private int[] ir2;
	private int[] press;
	private short[] axis_x;
	private short[] axis_y;
	private short[] axis_z;
	private int[] realXy;
	public ReadBinary_1(String filepath) {
		super();
		this.filepath = filepath;
		this.flag_five = false;
	}	
	public ReadBinary_1(String filepath, boolean flag_five) {
		super();
		this.filepath = filepath;
		this.flag_five = flag_five;
	}
	
	/**
	 * 读取二进制数据
	 * @return
	 */
/*	public OriginDataVo1 readBinary(){
		try {
			raf = new RandomAccessFile(filepath, "r");
			int len1=(int) (raf.length() / data_length);
			len = (int) (len1);
			int count=0;

			if (flag_five == false) {
				origindata=new OriginDataVo1(len);
				ml = new int[len];
				xy = new int[len];
				numTime = new long[len];
				PI = new int[len];
				status = new int[len];
				RR = new float[len];
				head1 = new int[len];
				head2 = new int[len];
				battery = new int[len];
				index = new int[len];
				numTime = new long[len];
				checkSum = new int[len];
				ir1 = new int[len];
				ir2 = new int[len];
				press=new int[len];
				axis_x=new short[len];
				axis_y=new short[len];
				axis_z=new short[len];
				realXy=new int[len];
				for (int i = 0; i < len1; i++) {
					raf.seek(i * data_length);
					head1[count]=0xFF & raf.readByte();
					head2[count]=0xFF & raf.readByte();
					index[count]=0xFF & raf.readByte();
					status[count]=0xFF & raf.readByte();
					ml[count] = 0xFF & raf.readByte();
					xy[count] = 0xFF & raf.readByte();
					PI[count] = 0xFF & raf.readByte();
					battery[count]=0xFF & raf.readByte();
					RR[count]=Float.valueOf(raf.readInt()) / packagelength;
					axis_x[count]=raf.readShort();
					axis_y[count]=raf.readShort();
					axis_z[count]=raf.readShort();
					press[count]=raf.readInt();
					ir1[count]=raf.readInt();
					checkSum[count]=0xFF & raf.readByte();
					numTime[count] = raf.readLong();
					count++;
				}
				origindata.setMl(ml);
				origindata.setXy(xy);
				origindata.setPI(PI);
				origindata.setStatus(status);
				origindata.setRR(RR);
				origindata.setHead1(head1);
				origindata.setHead2(head2);
				origindata.setBattery(battery);
				origindata.setIndex(index);
				origindata.setNumTime(numTime);
				origindata.setCheckSum(checkSum);
				origindata.setIr1(ir1);
				origindata.setPress(press);
				origindata.setAxis_x(axis_x);
				origindata.setAxis_y(axis_y);
				origindata.setAxis_z(axis_z);

			} else {
				origindata=new OriginDataVo1(len-360*packageRate);
				ml = new int[len-360*packageRate];
				xy = new int[len-360*packageRate];
				numTime = new long[len-360*packageRate];
				PI = new int[len-360*packageRate];
				status = new int[len-360*packageRate];
				RR = new float[len-360*packageRate];
				head1 = new int[len-360*packageRate];
				head2 = new int[len-360*packageRate];
				battery = new int[len-360*packageRate];
				index = new int[len-360*packageRate];
				numTime = new long[len-360*packageRate];
				checkSum = new int[len-360*packageRate];
				ir1 = new int[len-360*packageRate];
				ir2 = new int[len-360*packageRate];
				press=new int[len-360*packageRate];
				axis_x=new short[len-360*packageRate];
				axis_y=new short[len-360*packageRate];
				axis_z=new short[len-360*packageRate];
				realXy=new int[len-360*packageRate];
				for (int i = 0; i < len - 360*packageRate; i++) {
					raf.seek((i + 300*packageRate) * data_length);
					head1[count]=0xFF & raf.readByte();
					head2[count]=0xFF & raf.readByte();
					index[count]=0xFF & raf.readByte();
					status[count]=0xFF & raf.readByte();
					ml[count] = 0xFF & raf.readByte();
					xy[count] = 0xFF & raf.readByte();
					PI[count] = 0xFF & raf.readByte();
					battery[count]=0xFF & raf.readByte();
					RR[count]=Float.valueOf(raf.readInt()) / packagelength;
					axis_x[count]=raf.readShort();
					axis_y[count]=raf.readShort();
					axis_z[count]=raf.readShort();
					press[count]=raf.readInt();
					ir1[count]=raf.readInt();
					checkSum[count]=0xFF & raf.readByte();
					numTime[count] = raf.readLong();
					count++;
				}
				origindata.setMl(ml);
				origindata.setXy(xy);
				origindata.setPI(PI);
				origindata.setStatus(status);
				origindata.setRR(RR);
				origindata.setHead1(head1);
				origindata.setHead2(head2);
				origindata.setBattery(battery);
				origindata.setIndex(index);
				origindata.setNumTime(numTime);
				origindata.setCheckSum(checkSum);
				origindata.setIr1(ir1);
				origindata.setPress(press);
				origindata.setAxis_x(axis_x);
				origindata.setAxis_y(axis_y);
				origindata.setAxis_z(axis_z);

			}
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
		}		
		return origindata;
	}*/
	
	/**
	 * 读取呼吸版的.dat数据文件
	 * @return
	 */
	public OriginDataVo1 readBinary(){
		try {
			raf = new RandomAccessFile(filepath, "r");
			int len1=(int) (raf.length() / data_length);
			len = (int) (len1);
			int count=0;

			if (flag_five == false) {
				origindata=new OriginDataVo1(len);
				ml = new int[len];
				xy = new int[len];
				numTime = new long[len];
				PI = new int[len];
				status = new int[len];
				RR = new double[len];
				head1 = new int[len];
				head2 = new int[len];
				battery = new int[len];
				index = new int[len];
				numTime = new long[len];
				checkSum = new int[len];
				ir1 = new int[len];
				ir2 = new int[len];
				press=new int[len];
				axis_x=new short[len];
				axis_y=new short[len];
				axis_z=new short[len];
				realXy=new int[len];
				for (int i = 0; i < len1; i++) {
					raf.seek(i * data_length);
					head1[count]=0xFF & raf.readByte();
					head2[count]=0xFF & raf.readByte();
					index[count]=0xFF & raf.readByte();
					status[count]=0xFF & raf.readByte();
					ml[count] = 0xFF & raf.readByte();
					xy[count] = 0xFF & raf.readByte();
					PI[count] = 0xFF & raf.readByte();
					battery[count]=0xFF & raf.readByte();
					RR[count]=Float.valueOf(raf.readInt()) / packagelength;
					axis_x[count]=raf.readShort();
					axis_y[count]=raf.readShort();
					axis_z[count]=raf.readShort();
					press[count]=raf.readInt();
					ir1[count]=raf.readInt();
					checkSum[count]=0xFF & raf.readByte();
					numTime[count] = raf.readLong();
					count++;
				}
				origindata.setMl(ml);
				origindata.setXy(xy);
				origindata.setPI(PI);
				origindata.setStatus(status);
				origindata.setRR(RR);
				origindata.setHead1(head1);
				origindata.setHead2(head2);
				origindata.setBattery(battery);
				origindata.setIndex(index);
				origindata.setNumTime(numTime);
				origindata.setCheckSum(checkSum);
				origindata.setIr1(ir1);
				origindata.setPress(press);
				origindata.setAxis_x(axis_x);
				origindata.setAxis_y(axis_y);
				origindata.setAxis_z(axis_z);

			} else {
				origindata=new OriginDataVo1(len-360*packageRate);
				ml = new int[len-360*packageRate];
				xy = new int[len-360*packageRate];
				numTime = new long[len-360*packageRate];
				PI = new int[len-360*packageRate];
				status = new int[len-360*packageRate];
				RR = new double[len-360*packageRate];
				head1 = new int[len-360*packageRate];
				head2 = new int[len-360*packageRate];
				battery = new int[len-360*packageRate];
				index = new int[len-360*packageRate];
				numTime = new long[len-360*packageRate];
				checkSum = new int[len-360*packageRate];
				ir1 = new int[len-360*packageRate];
				ir2 = new int[len-360*packageRate];
				press=new int[len-360*packageRate];
				axis_x=new short[len-360*packageRate];
				axis_y=new short[len-360*packageRate];
				axis_z=new short[len-360*packageRate];
				realXy=new int[len-360*packageRate];
				for (int i = 0; i < len - 360*packageRate; i++) {
					raf.seek((i + 300*packageRate) * data_length);
					head1[count]=0xFF & raf.readByte();
					head2[count]=0xFF & raf.readByte();
					index[count]=0xFF & raf.readByte();
					status[count]=0xFF & raf.readByte();
					ml[count] = 0xFF & raf.readByte();
					xy[count] = 0xFF & raf.readByte();
					PI[count] = 0xFF & raf.readByte();
					battery[count]=0xFF & raf.readByte();
					RR[count]=Float.valueOf(raf.readInt()) / packagelength;
					axis_x[count]=raf.readShort();
					axis_y[count]=raf.readShort();
					axis_z[count]=raf.readShort();
					press[count]=raf.readInt();
					ir1[count]=raf.readInt();
					checkSum[count]=0xFF & raf.readByte();
					numTime[count] = raf.readLong();
					count++;
				}
				origindata.setMl(ml);
				origindata.setXy(xy);
				origindata.setPI(PI);
				origindata.setStatus(status);
				origindata.setRR(RR);
				origindata.setHead1(head1);
				origindata.setHead2(head2);
				origindata.setBattery(battery);
				origindata.setIndex(index);
				origindata.setNumTime(numTime);
				origindata.setCheckSum(checkSum);
				origindata.setIr1(ir1);
				origindata.setPress(press);
				origindata.setAxis_x(axis_x);
				origindata.setAxis_y(axis_y);
				origindata.setAxis_z(axis_z);

			}
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
		}		
		return origindata;
	}
	
	/**
	 * 读取呼吸版的.gz数据文件
	 * @return
	 */
	public OriginDataVo1 readGZBinary(){
		try {
			/*InputStream mInputStream=new GZIPInputStream(new FileInputStream(new File(filepath)));
			BufferedInputStream bufferedInputStream= new BufferedInputStream(mInputStream);
			int length = 0;
			bufferedInputStream.mark(Integer.MAX_VALUE);
			while (bufferedInputStream.read() != -1) {
				length++;
			}
			length /= dataPackageLength;*/
			
			
			raf = new RandomAccessFile(filepath, "r");
			int len1=(int) (raf.length() / data_length);
			len = (int) (len1);
			int count=0;

			if (flag_five == false) {
				origindata=new OriginDataVo1(len);
				ml = new int[len];
				xy = new int[len];
				numTime = new long[len];
				PI = new int[len];
				status = new int[len];
				RR = new double[len];
				head1 = new int[len];
				head2 = new int[len];
				battery = new int[len];
				index = new int[len];
				numTime = new long[len];
				checkSum = new int[len];
				ir1 = new int[len];
				ir2 = new int[len];
				press=new int[len];
				axis_x=new short[len];
				axis_y=new short[len];
				axis_z=new short[len];
				realXy=new int[len];
				for (int i = 0; i < len1; i++) {
					raf.seek(i * data_length);
					head1[count]=0xFF & raf.readByte();
					head2[count]=0xFF & raf.readByte();
					index[count]=0xFF & raf.readByte();
					status[count]=0xFF & raf.readByte();
					ml[count] = 0xFF & raf.readByte();
					xy[count] = 0xFF & raf.readByte();
					PI[count] = 0xFF & raf.readByte();
					battery[count]=0xFF & raf.readByte();
					RR[count]=Float.valueOf(raf.readInt()) / packagelength;
					axis_x[count]=raf.readShort();
					axis_y[count]=raf.readShort();
					axis_z[count]=raf.readShort();
					press[count]=raf.readInt();
					ir1[count]=raf.readInt();
					checkSum[count]=0xFF & raf.readByte();
					numTime[count] = raf.readLong();
					count++;
				}
				origindata.setMl(ml);
				origindata.setXy(xy);
				origindata.setPI(PI);
				origindata.setStatus(status);
				origindata.setRR(RR);
				origindata.setHead1(head1);
				origindata.setHead2(head2);
				origindata.setBattery(battery);
				origindata.setIndex(index);
				origindata.setNumTime(numTime);
				origindata.setCheckSum(checkSum);
				origindata.setIr1(ir1);
				origindata.setPress(press);
				origindata.setAxis_x(axis_x);
				origindata.setAxis_y(axis_y);
				origindata.setAxis_z(axis_z);

			} else {
				origindata=new OriginDataVo1(len-360*packageRate);
				ml = new int[len-360*packageRate];
				xy = new int[len-360*packageRate];
				numTime = new long[len-360*packageRate];
				PI = new int[len-360*packageRate];
				status = new int[len-360*packageRate];
				RR = new double[len-360*packageRate];
				head1 = new int[len-360*packageRate];
				head2 = new int[len-360*packageRate];
				battery = new int[len-360*packageRate];
				index = new int[len-360*packageRate];
				numTime = new long[len-360*packageRate];
				checkSum = new int[len-360*packageRate];
				ir1 = new int[len-360*packageRate];
				ir2 = new int[len-360*packageRate];
				press=new int[len-360*packageRate];
				axis_x=new short[len-360*packageRate];
				axis_y=new short[len-360*packageRate];
				axis_z=new short[len-360*packageRate];
				realXy=new int[len-360*packageRate];
				for (int i = 0; i < len - 360*packageRate; i++) {
					raf.seek((i + 300*packageRate) * data_length);
					head1[count]=0xFF & raf.readByte();
					head2[count]=0xFF & raf.readByte();
					index[count]=0xFF & raf.readByte();
					status[count]=0xFF & raf.readByte();
					ml[count] = 0xFF & raf.readByte();
					xy[count] = 0xFF & raf.readByte();
					PI[count] = 0xFF & raf.readByte();
					battery[count]=0xFF & raf.readByte();
					RR[count]=Float.valueOf(raf.readInt()) / packagelength;
					axis_x[count]=raf.readShort();
					axis_y[count]=raf.readShort();
					axis_z[count]=raf.readShort();
					press[count]=raf.readInt();
					ir1[count]=raf.readInt();
					checkSum[count]=0xFF & raf.readByte();
					numTime[count] = raf.readLong();
					count++;
				}
				origindata.setMl(ml);
				origindata.setXy(xy);
				origindata.setPI(PI);
				origindata.setStatus(status);
				origindata.setRR(RR);
				origindata.setHead1(head1);
				origindata.setHead2(head2);
				origindata.setBattery(battery);
				origindata.setIndex(index);
				origindata.setNumTime(numTime);
				origindata.setCheckSum(checkSum);
				origindata.setIr1(ir1);
				origindata.setPress(press);
				origindata.setAxis_x(axis_x);
				origindata.setAxis_y(axis_y);
				origindata.setAxis_z(axis_z);

			}
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
		}		
		return origindata;
	}
	
	
	/**
	 * 另存一份TXT文件
	 */
	public void saveASTxT(){	
		//String filename=SaveUtils.getUUIDName(filepath);
		String newFilepath=filepath.replace(".dat", ".txt");
		File file = new File(newFilepath);
		System.out.println(newFilepath);
		try {
			Writer out = new FileWriter(file);
			out.write("Time(long)" + "     " + "ml" + "  " + "xy" + "  " + "press"+"   "+"RR"+"   "+"ir1");
			//out.write("ir1");
			out.flush();
			for (int i = 0; i < origindata.getLen(); i++) {
				out.write("\r\n" + origindata.getNumTime()[i] + "  " + origindata.getMl()[i] + "  "
						+ origindata.getXy()[i] + "  " +origindata.getPress()[i]+ "   "+origindata.getRR()[i]+"   "+origindata.getIr1()[i]);
				//out.write("\r\n"+origindata.getIr1()[i]);
				out.flush();
			}
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
