package read.origindata;

public class OriginDataVo1 extends OriginDataVo {

	private int[] press;
	private short[] axis_x;
	private short[] axis_y;
	private short[] axis_z;
	private int[] realXy;
	public OriginDataVo1(int len) {
		super(len);
	}
	public int[] getPress() {
		return press;
	}
	public void setPress(int[] press) {
		this.press = press;
	}
	public short[] getAxis_x() {
		return axis_x;
	}
	public void setAxis_x(short[] axis_x) {
		this.axis_x = axis_x;
	}
	public short[] getAxis_y() {
		return axis_y;
	}
	public void setAxis_y(short[] axis_y) {
		this.axis_y = axis_y;
	}
	public short[] getAxis_z() {
		return axis_z;
	}
	public void setAxis_z(short[] axis_z) {
		this.axis_z = axis_z;
	}
	public int[] getRealXy() {
		return realXy;
	}
	public void setRealXy(int[] realXy) {
		this.realXy = realXy;
	}

}
