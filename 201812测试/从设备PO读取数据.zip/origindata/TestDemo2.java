package read.origindata;

import java.io.File;
import org.junit.Test;

/**
 * 读取后台数据文件(.gz)
 * @author hd
 *
 */
public class TestDemo2 {
	/**
	 * 读取web后台的gz数据文件
	 * 把所有的信号存在txt文件中
	 * 
	 * @throws Exception
	 */
	@Test
	public void run1() throws Exception{
		//文件名称
		String filePath="C:/Users/PC/Desktop/医院睡眠数据1/轻度AHI/2/l2.gz";
		//数据路径
	    /*String filePath = "C:"+File.separator+"Users"+File.separator+"PC"+File.separator+"Desktop"+File.separator+    
	    	filename;*/
	    OriginGZDataVO readGZData=new OriginGZDataVO(filePath);
	    readGZData.saveASTxT();
	    //readGZData.saveRRASTxT();
	    System.out.println("程序运行结束....");
	}
	
	/**
	 * 读取web后台的gz数据文件
	 * 把RR间期数据存在txt文件中
	 * 
	 * @throws Exception
	 */
	@Test
	public void run2() throws Exception{
		//数据路径
		String filePath="C:/Users/PC/Desktop/医院睡眠数据1/data.gz";
		
	    OriginGZDataVO readGZData=new OriginGZDataVO(filePath);
	    readGZData.saveRRASTxT();
	    System.out.println("程序运行结束....");
	}
	
}
