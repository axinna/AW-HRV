package read.origindata;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.io.Writer;

public class ReadBinary {
	private String filepath;
	private boolean flag_five = false;
	private int len;
	private final int data_length = 30;
	private RandomAccessFile raf;
	private OriginDataVo origindata;
	private String TAG = "ReadBinary";

	private int[] ml;
	private int[] xy;
	private int[] PI;
	private int[] status;
	private double[] RR;
	private int[] head1;
	private int[] head2;
	private int[] battery;
	private int[] index;
	private long[] numTime;
	private int[] checkSum;
	private int[] ir1;
	private int[] ir2;
	private int[] reservedbyte;

	public ReadBinary(String filepath) {
		super();
		this.filepath = filepath;
		this.flag_five = false;
		readBinary();
	}

	/**
	 * 
	 * @param filepath
	 * @param flag_five
	 *            false:默认，不掐头去尾 true:去掉前五分钟和后一分钟
	 */
	public ReadBinary(String filepath, boolean flag_five) {
		super();
		this.filepath = filepath;
		this.flag_five = flag_five;
		readBinary();
	}

	/**
	 * 计算丢包率
	 * 
	 * @return
	 */
	public float getPkgLastRate() {
		int lostCount = 0;
		int oldIndex = 0;
		int indexLength = index.length;
		float lostRate = 0;
		
		if (indexLength>0) {
			for (int i = 0; i < indexLength; i++) {
				int newIndex = (int) (0xff & index[i]);
				if (newIndex != oldIndex + 1) {
					if (newIndex > oldIndex) {
						lostCount = lostCount + newIndex - oldIndex - 1;
					}
					if (newIndex < oldIndex) {
						lostCount = lostCount + newIndex + 255 - oldIndex;
					}
				}
				oldIndex = newIndex;
			}
			lostRate = 100 * lostCount / (indexLength + lostCount);
		}
		// 输出
		String recordpath = filepath + ":pkglost.txt";
		File file = new File(recordpath);
		try {
			Writer out = new FileWriter(file);
			out.write("\r\n丢包数量：" + lostCount + "现存包数量：" + indexLength + "丢包率：" + lostRate + "%");
			out.flush();
			for (int i = 0; i < indexLength; i++) {
				int newIndex = (int) (0xff & index[i]);
				out.write("\r\n index:" + newIndex);
				out.flush();
			}
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return lostRate;
	}

	/**
	 * 获取持续时间
	 * 
	 * @return 持续时间 毫秒
	 */
	public long getTimeLast() {
		int length = numTime.length;
		long last = 0;
		if (length > 1) {
			last = numTime[length - 1] - numTime[0];
		}
		return last;
	}

	/**
	 * 另存一份TXT文件
	 * 
	 * @param filepath
	 */
	public void saveASTxT() {
		//String recordpath = filepath + ":Record.txt";
		String newFilepath=filepath.replace(".dat", ".txt");
		File file = new File(newFilepath);
		System.out.println(newFilepath);
		try {
			Writer out = new FileWriter(file);
			out.write("Time(long)" + "  " + "ml" + "  " + "xy" + "  " + "RR" + "  " + "IR1" + "  " + "IR2\r\n");
			out.flush();
			for (int i = 0; i < origindata.getLen(); i++) {
				out.write("\r\n" + origindata.getNumTime()[i] + "  " + origindata.getMl()[i] + "  "
						+ origindata.getXy()[i] + "  " + origindata.getRR()[i] + "  " + origindata.getIr1()[i] + "  "
						+ origindata.getIr2()[i]);
				out.flush();
			}
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	
	/**
	 * 读二进制数据
	 * 
	 * @return
	 */
	public OriginDataVo readBinary() {
		try {
			raf = new RandomAccessFile(filepath, "r");
			len = (int) (raf.length() / data_length);

			if (flag_five == false) {
				origindata = new OriginDataVo(len);
				ml = new int[len];
				xy = new int[len];
				numTime = new long[len];
				PI = new int[len];
				status = new int[len];
				RR = new double[len];
				head1 = new int[len];
				head2 = new int[len];
				battery = new int[len];
				index = new int[len];
				numTime = new long[len];
				checkSum = new int[len];
				ir1 = new int[len];
				ir2 = new int[len];
				reservedbyte = new int[len];
				for (int i = 0; i < len; i++) {
					raf.seek(i * data_length);
					head1[i] = 0xFF & raf.readByte();
					head2[i] = 0xFF & raf.readByte();
					index[i] = 0xFF & raf.readByte();
					status[i] = 0xFF & raf.readByte();
					ml[i] = 0xFF & raf.readByte();
					xy[i] = 0xFF & raf.readByte();
					PI[i] = 0xFF & raf.readByte();
					battery[i] = 0xFF & raf.readByte();
					RR[i] = Float.valueOf(raf.readInt());
					ir1[i] = raf.readInt();
					ir2[i] = raf.readInt();
					reservedbyte[i] = raf.readByte();
					checkSum[i] = 0xFF & raf.readByte();
					numTime[i] = raf.readLong();
				}
				origindata.setMl(ml);
				origindata.setXy(xy);
				origindata.setPI(PI);
				origindata.setStatus(status);
				origindata.setRR(RR);
				origindata.setHead1(head1);
				origindata.setHead2(head2);
				origindata.setBattery(battery);
				origindata.setIndex(index);
				origindata.setNumTime(numTime);
				origindata.setCheckSum(checkSum);
				origindata.setIr1(ir1);
				origindata.setIr2(ir2);
			} else {
				origindata = new OriginDataVo(len - 360);
				ml = new int[len - 360];
				xy = new int[len - 360];
				numTime = new long[len - 360];
				PI = new int[len - 360];
				status = new int[len - 360];
				RR = new double[len - 360];
				head1 = new int[len - 360];
				head2 = new int[len - 360];
				battery = new int[len - 360];
				index = new int[len - 360];
				numTime = new long[len - 360];
				checkSum = new int[len - 360];
				ir1 = new int[len - 360];
				ir2 = new int[len - 360];
				reservedbyte = new int[len - 360];
				for (int i = 0; i < len - 360; i++) {
					raf.seek((i + 300) * data_length);
					head1[i] = 0xFF & raf.readByte();
					head2[i] = 0xFF & raf.readByte();
					index[i] = 0xFF & raf.readByte();
					status[i] = 0xFF & raf.readByte();
					ml[i] = 0xFF & raf.readByte();
					xy[i] = 0xFF & raf.readByte();
					PI[i] = 0xFF & raf.readByte();
					battery[i] = 0xFF & raf.readByte();
					RR[i] = Float.valueOf(raf.readInt());
					ir1[i] = raf.readInt();
					ir2[i] = raf.readInt();
					reservedbyte[i] = raf.readByte();
					checkSum[i] = 0xFF & raf.readByte();
					numTime[i] = raf.readLong();
				}
				origindata.setMl(ml);
				origindata.setXy(xy);
				origindata.setPI(PI);
				origindata.setStatus(status);
				origindata.setRR(RR);
				origindata.setHead1(head1);
				origindata.setHead2(head2);
				origindata.setBattery(battery);
				origindata.setIndex(index);
				origindata.setNumTime(numTime);
				origindata.setCheckSum(checkSum);
				origindata.setIr1(ir1);
				origindata.setIr2(ir2);
			}
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
		}
		return origindata;
	}

}
